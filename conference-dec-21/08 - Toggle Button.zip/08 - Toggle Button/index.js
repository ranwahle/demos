const button = document.querySelector('.toggle-button-container');

button.addEventListener('click', () => {
    button.classList.toggle('on');

})